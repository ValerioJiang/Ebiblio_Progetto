
<div class="container-fluid bg-danger text-white text-center">
    
        <h6>Copyright© cucc corp</h6>
    
</div>

</body>

</html>