<?php

include('/xampp/htdocs/ebiblio/admin/admin_partials/menu.php');

if (!isset($_GET['nuovolibro'])) {
    echo "<script type='text/javascript'>alert('Errore ritornare home');
                    window.location = 'http://localhost/ebiblio/admin/'; 
                    </script>";
} /*else {

    $biblioteca = $amministratoreCon->getLikeAmministratoreBiblio($_SESSION['email']);
    $titolotrim = trim($_GET['titolo']);
    $autoretrim = trim($_GET['autore']);
    $edizionetrim = trim($_GET['edizione']);
    $generetrim = trim($_GET['genere']);
    $annotrim = trim($_GET['anno']);
    $paginetrim = trim($_GET['pagine']);
    $conservazionetrim = trim($_GET['stato']);
    $scaffaletrim = trim($_GET['scaffale']);

    if ((ctype_space($titolotrim) || $titolotrim == '') || (ctype_space($autoretrim) || $autoretrim == '') || (ctype_space($edizionetrim) || $edizionetrim == '') || (ctype_space($generetrim) || $generetrim == '') || (ctype_space($annotrim) || $annotrim == '') || (ctype_space($paginetrim) || $paginetrim == '') || (ctype_space($conservazionetrim) || $conservazionetrim == '') || (ctype_space($scaffaletrim) || $scaffaletrim == '')) {
        echo "Per favore riempire tutti i campi";
    } else {
        $creazionecartaceo = $cartaceo_Con->createCartaceo($titolotrim, $autoretrim, $edizionetrim, $generetrim, $annotrim, $paginetrim, $conservazionetrim, $scaffaletrim, $biblio_res[0]['BibliotecaGestita']);
        echo "Libro inserito con successo";
    }
}*/

$nuovLibro = $_GET['nuovolibro'];
?>

<div class="container" style="background-color: white;">
    <br>
    <div class="container">
        <form action="/ebiblio/admin/nuovo_autori.php?" method="GET">
            <div class="form-group">
                <div class="row">
                    <div class="col mb-2">
                        <label for="titoloId">Numero Autori</label>
                        <div>
                                <label for='stato'>Stato libro</label>
                                    <select multiple class='form-control' name = 'stato' id='statolibro'>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    <option>6</option>
                                    <option>7</option>
                                    <option>8</option>
                                    <option>9</option>
                                    <option>10</option>
                                    </select>
                                    <br>
                            </div>
                    </div>
                </div>
            </div>
            <input type="submit" name="autform_submitted" class="btn btn-primary" value="Aggiungi Autori"></input>
        </form>
    </div>
    <?php
        if(isset($_GET['autform_submitted']) && isset($_GET['stato'])){
            for($i = 0; $i < $_GET['stato']; $i++){
                echo "<div class='row'>";
                echo "<input type='text' class='form-control' name='Titolo".$i."' id='titoloId' aria-describedby='emailHelp' placeholder='Inserire autore ".$i."'>";
                echo "<br>";
                echo "</div>";
                echo "<br>";
            }
            echo "";
        }
?>
</div>


<?php
include('/xampp/htdocs/ebiblio/admin/admin_partials/footer.php');
?>