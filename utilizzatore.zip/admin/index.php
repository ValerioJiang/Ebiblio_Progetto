<?php
include('/xampp/htdocs/ebiblio/admin/admin_partials/menu.php');

?>



  <?php
  include('/xampp/htdocs/ebiblio/admin/admin_partials/footer.php');
  ?>